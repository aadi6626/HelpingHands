import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import FormWrapper from "@/components/FormWrapper";
import CitySelect from "@/components/CitySelect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

const Request = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    needs: "",
    city: "",
    details: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.functions.invoke("submit-form", {
        body: { type: "request", data: formData }
      });

      if (error) throw error;

      toast.success("Request submitted successfully!");
      navigate("/confirmation?type=request&name=" + encodeURIComponent(formData.name));
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to submit request. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <FormWrapper
      title="Request Resources"
      description="If you or someone you know needs help, please let us know."
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-muted-foreground">Full Name</Label>
          <Input
            id="name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="needs" className="text-muted-foreground">Needs (Food, Shelter, Clothes)</Label>
          <Select value={formData.needs} onValueChange={(val) => setFormData({ ...formData, needs: val })}>
            <SelectTrigger className="bg-white/5 border-white/20 text-foreground focus:border-accent">
              <SelectValue placeholder="Select Requirement" />
            </SelectTrigger>
            <SelectContent className="bg-card border-white/20">
              <SelectItem value="Food">Food</SelectItem>
              <SelectItem value="Shelter">Shelter</SelectItem>
              <SelectItem value="Clothing">Clothing</SelectItem>
              <SelectItem value="Medical">Medical Aid</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="city" className="text-muted-foreground">City</Label>
          <CitySelect
            value={formData.city}
            onValueChange={(val) => setFormData({ ...formData, city: val })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="details" className="text-muted-foreground">Details</Label>
          <Textarea
            id="details"
            rows={3}
            placeholder="Describe the situation..."
            value={formData.details}
            onChange={(e) => setFormData({ ...formData, details: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30 resize-none"
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full btn-gradient text-white font-bold py-6 text-base uppercase tracking-wider border-0"
        >
          {isSubmitting ? "Submitting..." : "Submit Request"}
        </Button>
      </form>
    </FormWrapper>
  );
};

export default Request;
