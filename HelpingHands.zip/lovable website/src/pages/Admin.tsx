import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, HandHeart, AlertTriangle, Building2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Donation {
  id: string;
  name: string;
  item: string;
  city: string;
  created_at: string;
}

interface Request {
  id: string;
  name: string;
  needs: string;
  city: string;
  details: string | null;
  created_at: string;
}

interface Report {
  id: string;
  type: string;
  location_detail: string;
  city: string;
  description: string | null;
  created_at: string;
}

interface NGO {
  id: string;
  name: string;
  reg_number: string;
  city: string;
  contact: string;
  created_at: string;
}

const Admin = () => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [ngos, setNgos] = useState<NGO[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    const [donRes, reqRes, repRes, ngoRes] = await Promise.all([
      supabase.from("donations").select("*").order("created_at", { ascending: false }),
      supabase.from("requests").select("*").order("created_at", { ascending: false }),
      supabase.from("reports").select("*").order("created_at", { ascending: false }),
      supabase.from("ngos").select("*").order("created_at", { ascending: false }),
    ]);

    if (donRes.data) setDonations(donRes.data);
    if (reqRes.data) setRequests(reqRes.data);
    if (repRes.data) setReports(repRes.data);
    if (ngoRes.data) setNgos(ngoRes.data);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container py-24">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gradient">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-2">View all form submissions</p>
          </div>
          <Button onClick={fetchData} disabled={loading} variant="outline" className="gap-2">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Heart className="w-4 h-4 text-accent" /> Donations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{donations.length}</p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <HandHeart className="w-4 h-4 text-secondary" /> Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{requests.length}</p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-500" /> Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{reports.length}</p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Building2 className="w-4 h-4 text-primary" /> NGOs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{ngos.length}</p>
            </CardContent>
          </Card>
        </div>

        {/* Data Tables */}
        <Tabs defaultValue="donations" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="donations">Donations</TabsTrigger>
            <TabsTrigger value="requests">Requests</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="ngos">NGOs</TabsTrigger>
          </TabsList>

          <TabsContent value="donations">
            <Card className="glass-card">
              <CardContent className="pt-6">
                {donations.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No donations yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Item</TableHead>
                        <TableHead>City</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {donations.map((d) => (
                        <TableRow key={d.id}>
                          <TableCell className="font-medium">{d.name}</TableCell>
                          <TableCell>{d.item}</TableCell>
                          <TableCell>{d.city}</TableCell>
                          <TableCell>{formatDate(d.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requests">
            <Card className="glass-card">
              <CardContent className="pt-6">
                {requests.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No requests yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Needs</TableHead>
                        <TableHead>City</TableHead>
                        <TableHead>Details</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {requests.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="font-medium">{r.name}</TableCell>
                          <TableCell>{r.needs}</TableCell>
                          <TableCell>{r.city}</TableCell>
                          <TableCell className="max-w-[200px] truncate">{r.details || "-"}</TableCell>
                          <TableCell>{formatDate(r.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="glass-card">
              <CardContent className="pt-6">
                {reports.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No reports yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>City</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reports.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="font-medium">{r.type}</TableCell>
                          <TableCell>{r.location_detail}</TableCell>
                          <TableCell>{r.city}</TableCell>
                          <TableCell className="max-w-[200px] truncate">{r.description || "-"}</TableCell>
                          <TableCell>{formatDate(r.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ngos">
            <Card className="glass-card">
              <CardContent className="pt-6">
                {ngos.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No NGOs registered yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Reg. Number</TableHead>
                        <TableHead>City</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ngos.map((n) => (
                        <TableRow key={n.id}>
                          <TableCell className="font-medium">{n.name}</TableCell>
                          <TableCell>{n.reg_number}</TableCell>
                          <TableCell>{n.city}</TableCell>
                          <TableCell>{n.contact}</TableCell>
                          <TableCell>{formatDate(n.created_at)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
    </div>
  );
};

export default Admin;
