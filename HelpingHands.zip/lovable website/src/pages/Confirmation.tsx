import { useSearchParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const Confirmation = () => {
  const [searchParams] = useSearchParams();
  const type = searchParams.get("type") || "submission";
  const name = searchParams.get("name") || searchParams.get("reporter") || "";

  const typeLabels: Record<string, string> = {
    request: "Resource Request",
    donate: "Donation Pledge",
    report: "Incident Report",
    ngo: "NGO Registration",
  };

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="glass-card p-12 rounded-2xl text-center max-w-lg"
      >
        <div className="w-20 h-20 mx-auto mb-6 rounded-full btn-gradient flex items-center justify-center animate-pulse-glow">
          <CheckCircle className="text-white" size={40} />
        </div>
        <h2 className="text-3xl font-bold text-foreground mb-4">Submission Successful!</h2>
        <p className="text-muted-foreground mb-6">
          Thank you{name ? `, ${name}` : ""}! Your <span className="text-accent font-medium">{typeLabels[type] || "submission"}</span> has been received.
        </p>
        <p className="text-muted-foreground mb-8">
          We appreciate your contribution to making the world a better place.
        </p>
        <Link to="/">
          <Button className="btn-gradient text-white font-bold px-8 py-6 text-base uppercase tracking-wider border-0">
            Go to Homepage
          </Button>
        </Link>
      </motion.div>
    </main>
  );
};

export default Confirmation;
