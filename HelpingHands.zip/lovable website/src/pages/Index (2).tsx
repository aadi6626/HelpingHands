import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import StatCard from "@/components/StatCard";
import { Button } from "@/components/ui/button";

const Index = () => {
  return (
    <div>
      {/* Hero Section */}
      <header className="min-h-[90vh] flex items-center justify-center mt-[70px] text-center relative px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl z-10"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
            Extending Funds,{" "}
            <br />
            <span className="text-gradient">Changing Lives</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Join us in our mission to eradicate hunger and homelessness. Together, we can make a difference in our Indian cities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/donate">
              <Button className="btn-gradient text-white font-bold px-8 py-6 text-base uppercase tracking-wider border-0">
                Donate Now
              </Button>
            </Link>
            <Link to="/request">
              <Button variant="outline" className="border-2 border-accent text-accent hover:bg-accent hover:text-white px-8 py-6 text-base uppercase tracking-wider font-bold bg-transparent">
                Request Help
              </Button>
            </Link>
          </div>
        </motion.div>
      </header>

      {/* Stats Section */}
      <section className="py-24 px-6">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-foreground mb-4">Real-Time Data</h2>
            <p className="text-muted-foreground">Data insights powered by AI</p>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-10 max-w-5xl mx-auto">
            <StatCard icon="🏠" target={12450} label="Homeless People Identified" delay={0} />
            <StatCard icon="🍲" target={8320} label="Hungry People Fed Today" delay={0.1} />
            <StatCard icon="🤝" target={450} label="Active NGOs" delay={0.2} />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
