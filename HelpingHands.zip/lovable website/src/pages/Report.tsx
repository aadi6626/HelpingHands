import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import FormWrapper from "@/components/FormWrapper";
import CitySelect from "@/components/CitySelect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

const Report = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    reporter: "",
    type: "",
    city: "",
    locationDetail: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.functions.invoke("submit-form", {
        body: { type: "report", data: formData }
      });

      if (error) throw error;

      toast.success("Report submitted successfully!");
      navigate("/confirmation?type=report&reporter=" + encodeURIComponent(formData.reporter || "Anonymous"));
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to submit report. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <FormWrapper
      title="Report an Incident"
      description="Help us identify homeless people or report critical needs in your area."
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="reporter" className="text-muted-foreground">Your Name (Optional)</Label>
          <Input
            id="reporter"
            value={formData.reporter}
            onChange={(e) => setFormData({ ...formData, reporter: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="type" className="text-muted-foreground">Incident Type</Label>
          <Select value={formData.type} onValueChange={(val) => setFormData({ ...formData, type: val })}>
            <SelectTrigger className="bg-white/5 border-white/20 text-foreground focus:border-accent">
              <SelectValue placeholder="Select Incident Type" />
            </SelectTrigger>
            <SelectContent className="bg-card border-white/20">
              <SelectItem value="Homeless Sighting">Homeless Person Sighting</SelectItem>
              <SelectItem value="Medical Emergency">Medical Emergency (Non-Critical)</SelectItem>
              <SelectItem value="Hunger Crisis">Hunger Crisis</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="city" className="text-muted-foreground">Location (City)</Label>
          <CitySelect
            value={formData.city}
            onValueChange={(val) => setFormData({ ...formData, city: val })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="locationDetail" className="text-muted-foreground">Specific Location/Landmark</Label>
          <Input
            id="locationDetail"
            required
            value={formData.locationDetail}
            onChange={(e) => setFormData({ ...formData, locationDetail: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full btn-gradient text-white font-bold py-6 text-base uppercase tracking-wider border-0"
        >
          {isSubmitting ? "Submitting..." : "Report Now"}
        </Button>
      </form>
    </FormWrapper>
  );
};

export default Report;
