import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import FormWrapper from "@/components/FormWrapper";
import CitySelect from "@/components/CitySelect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

const Donate = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    item: "",
    city: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.functions.invoke("submit-form", {
        body: { type: "donate", data: formData }
      });

      if (error) throw error;

      toast.success("Donation pledged successfully!");
      navigate("/confirmation?type=donate&name=" + encodeURIComponent(formData.name));
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to submit donation. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <FormWrapper
      title="Donate Resources"
      description="Your contribution can save a life."
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-muted-foreground">Donor Name</Label>
          <Input
            id="name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="item" className="text-muted-foreground">Item to Donate</Label>
          <Input
            id="item"
            required
            placeholder="e.g. Blankets, Rice bags"
            value={formData.item}
            onChange={(e) => setFormData({ ...formData, item: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="city" className="text-muted-foreground">Pickup City</Label>
          <CitySelect
            value={formData.city}
            onValueChange={(val) => setFormData({ ...formData, city: val })}
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full btn-gradient text-white font-bold py-6 text-base uppercase tracking-wider border-0"
        >
          {isSubmitting ? "Submitting..." : "Pledge Donation"}
        </Button>
      </form>
    </FormWrapper>
  );
};

export default Donate;
