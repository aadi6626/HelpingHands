import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import FormWrapper from "@/components/FormWrapper";
import CitySelect from "@/components/CitySelect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

const NGO = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    regNumber: "",
    city: "",
    contact: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.functions.invoke("submit-form", {
        body: { type: "ngo", data: formData }
      });

      if (error) throw error;

      toast.success("NGO registered successfully!");
      navigate("/confirmation?type=ngo&name=" + encodeURIComponent(formData.name));
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to register NGO. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <FormWrapper
      title="NGO Registration"
      description="Join our network to receive alerts and manage resources."
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-muted-foreground">Organization Name</Label>
          <Input
            id="name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="regNumber" className="text-muted-foreground">Registration Number</Label>
          <Input
            id="regNumber"
            required
            value={formData.regNumber}
            onChange={(e) => setFormData({ ...formData, regNumber: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="city" className="text-muted-foreground">Base City</Label>
          <CitySelect
            value={formData.city}
            onValueChange={(val) => setFormData({ ...formData, city: val })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact" className="text-muted-foreground">Contact Number</Label>
          <Input
            id="contact"
            type="tel"
            required
            value={formData.contact}
            onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
            className="bg-white/5 border-white/20 text-foreground focus:border-accent focus:ring-accent/30"
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full border-2 border-accent text-accent hover:bg-accent hover:text-white font-bold py-6 text-base uppercase tracking-wider bg-transparent"
        >
          {isSubmitting ? "Registering..." : "Register NGO"}
        </Button>
      </form>
    </FormWrapper>
  );
};

export default NGO;
